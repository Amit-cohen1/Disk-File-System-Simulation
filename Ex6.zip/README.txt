EX6 final - Disk Management 
Author: Amit Cohen
315640623

==Description==

In this exercise, the user will enter a number between 1-8 to preform action simualting the disk management.

We will use the different methods declared in the exercise demands to excute the different commands.
We will allow to use the disk as close as we can simulate to the real Management disk. I choose to use in the vector and pointer to array 
structures to mantain the diffrent structs. I keep update the structs in all of the methods.


==Program Files==
ex6.c


==how to compile?==

compile: gcc ex6.c -o ex6 
run: ./ex6a

==Input:==
It depands wich option we choose. We follow the order according to the number and than we expect to get a following string or FD in order to
 manipuliate the disk simulation.


==Output:==
Depand on the request. Mostly you can see the output using the 1 option that show the current state of disk.

The README was written at 2am sorry about my English :)


